A mod made by @rmjwmmd on discord! Tag me in the MGD dicord or DM me on discord with any feedback you may have!

A dragon girl mod with a hopefully decent array of content for everyone! Fight against the 5 chromatic dragons, a whelpling, a powerful purple dragon, and the horniest MOAD: Tiamat!

Future updates I hope to use to flesh out the location, as well as add more victory and loss scenes to the dragons, but I plan on splitting time between this mod and adding more monsters to the sitting mod.

The images for the dragons comes from Kanel_Art on Patreon, or @BurnRev on Twitter
As a warning Kanel has a lot of futa and "cumsplosion" art so if that turns you off that's your warning.

Adds 3 runes and 3 equippable items, and I plan on adding skills that will be learnable from the Blue Dragon.

Dragon Mod Update 1.04 adds
White Dragon: Thighjob, Footjob loss scenes
Red Dragon: Anal, Facesitting loss scenes
Purple Dragon: Footjob, Thighjob loss scenes
Green Dragon:Facesitting, Footjob
Black Dragon: Sex, Footjob